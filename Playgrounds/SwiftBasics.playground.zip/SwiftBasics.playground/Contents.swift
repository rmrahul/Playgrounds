//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



///#### OPTIONAL BINDING..
var optionalVar : String?


if let val = optionalVar{
    print(val)
}

if var other = optionalVar{
    other = "Mane"
    print(other,optionalVar)
}

func testGuardlet(){
    optionalVar = "assinged"

    guard var value2 = optionalVar else {
        print("No value")
        return
    }
    
    value2 = "Mane"
    
    guard let value1 = optionalVar else {
        print("No value")
        return
    }
    
    print(value1,value2)
}

testGuardlet()


