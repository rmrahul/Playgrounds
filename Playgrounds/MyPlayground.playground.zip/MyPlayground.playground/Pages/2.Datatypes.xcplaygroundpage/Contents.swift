//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

var value : UInt

let twoThousand: UInt16 = 2_0_0_0
print(twoThousand)
