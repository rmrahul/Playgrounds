//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//The value of a constant doesn’t need to be known at compile time, but you must assign it a value exactly once.
let value : String
value = "Some constant string"

// We cannot execute following statement as it says let varible can assign exactly once.
//value = "Some constant string"
print(value)



//Values are never implicitly converted to another type. If you need to convert a value to a different type, explicitly make an instance of the desired type.
let label = "The width is "
let width = 94
let widthLabel = label + String(width)
