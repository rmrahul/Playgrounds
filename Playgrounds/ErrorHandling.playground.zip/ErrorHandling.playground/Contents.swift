//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

enum VendingMachineError: Error {
    case invalidSelection
    case insufficientFunds(coinsNeeded: Int)
    case outOfStock
}

struct Item {
    var price: Int
    var count: Int
}


class VendingMachine {
    var inventory = [
        "Candy Bar": Item(price: 12, count: 7),
        "Chips": Item(price: 10, count: 4),
        "Pretzels": Item(price: 7, count: 11)
    ]
    var coinsDeposited = 0
    
    func vend(itemNamed name: String) throws {
        defer{
            print("Defer 1 : this will be executed second because of reverse order")
        }
        
        defer{
            print("Defer 2 : this will be executed first because of reverse order")
        }
        
        guard let item = inventory[name] else {
            throw VendingMachineError.invalidSelection
        }
        
        guard item.count > 0 else {
            throw VendingMachineError.outOfStock
        }
        
        guard item.price <= coinsDeposited else {
            throw VendingMachineError.insufficientFunds(coinsNeeded: item.price - coinsDeposited)
        }
        
        coinsDeposited -= item.price
        
        var newItem = item
        newItem.count -= 1
        inventory[name] = newItem
        
        print("Dispensing \(name)")
        
        defer{
            print("Defer 3 : This will not executed.. because it's not registred. This will only registres if there is no exception")
        }
    }
}

let favoriteSnacks = [
    "Alice": "Chips",
    "Bob": "Licorice",
    "Eve": "Pretzels",
]


func main() throws{
    print("Starting main")
    let vendingMachine = VendingMachine()
    vendingMachine.coinsDeposited = 10
    do {
        try buyFavoriteSnack(person: "Alice", vendingMachine: vendingMachine)
        print("Success! Yum.")
    } catch VendingMachineError.invalidSelection {
        print("Invalid Selection.")
    } catch VendingMachineError.outOfStock {
        print("Out of Stock.")
    }
    catch{
        print("Un Handled exception",error)
    }
    
    print("End of main")
}

func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) throws {
    let snackName = favoriteSnacks[person] ?? "Candy Bar"
    try vendingMachine.vend(itemNamed: snackName)
}

func runThrowingFunction(throwingFunction : (String) throws -> (),parameterForThrowingFunction : String) throws{
    try throwingFunction(parameterForThrowingFunction)
}

runThrowingFunction(throwingFunction: venu, parameterForThrowingFunction: <#T##String#>)
print("End of file")

